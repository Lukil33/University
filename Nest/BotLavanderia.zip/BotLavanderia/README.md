# nlp-laundry

Basic script to parse laundry group messages.

## Quickstart

```
python3 text_parser.py
```

## Message examples

```
Lavatrice A e B 1 ora e 5 minuti

Lavatrice B 10 minuti

Lavatrice A 3 minuti
```
